from telebot import TeleBot, types
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from data import db_session
from word import Word
import requests as rp

TEXT_INPUT = False

engine = create_engine('sqlite:///flash_cards.db')
Session = sessionmaker(bind=engine)

bot = TeleBot("Test_bot")


def create_word(russian_word, foreign_word, memory_level=1):
    word = Word(russian_word=russian_word, foreign_word=foreign_word, memory_level=memory_level)
    session = Session()
    session.add(word)
    session.commit()
    session.close()


def ordered_words():
    session = Session()
    ordered_words = session.query(Word).order_by(Word.memory_level).all()
    session.close()
    return ordered_words


@bot.message_handler(commands=["start"])
def start(message):
    global TEXT_INPUT
    TEXT_INPUT = False
    welcome_message = "Добро пожаловать в бот флеш карточки!"
    keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.row("Словари", "Тренировка")
    bot.send_message(message.chat.id, welcome_message, reply_markup=keyboard)


@bot.message_handler(func=lambda message: TEXT_INPUT)
def receive_text(message):
    global TEXT_INPUT
    words = message.text.split()
    for word_pair in words:
        russian, foreign = word_pair.split()
        create_word(russian, foreign)
    TEXT_INPUT = False
    bot.send_message(message.chat.id, "Слова успешно добавлены в словарь!")


@bot.message_handler(func=lambda message: message.text == "Словари")
def dictionaries(message):
    global TEXT_INPUT
    TEXT_INPUT = True
    bot.send_message(message.chat.id, "Введите слова для изучения через пробел",
                     reply_markup=types.ReplyKeyboardRemove())


@bot.message_handler(func=lambda message: message.text == "Тренировка")
def training(message):
    ordered = ordered_words()
    for word in ordered:
        bot.send_message(message.chat.id,
                         f"Russian: {word.russian_word}, Foreign: {word.foreign_word}, Memory Level: {word.memory_level}")


if __name__ == "__main__":
    db_session.global_init('flash_cards.db')
    bot.polling()
