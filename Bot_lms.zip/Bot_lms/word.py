import sqlalchemy
from data.db_session import SqlAlchemyBase


class Word(SqlAlchemyBase):
    __tablename__ = 'words'

    id = sqlalchemy.Column(sqlalchemy.Integer,
                           primary_key=True, autoincrement=True)
    russian_word = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    foreigh_word = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    memory_level = sqlalchemy.Column(sqlalchemy.Integer, nullable=True)
