from telebot import TeleBot
from app.config import TOKEN

bot = TeleBot(TOKEN)
